<?php $__env->startSection('body-class','landing-page sidebar-collapse'); ?>

<?php $__env->startSection('content'); ?>
<div class="wrapper">
  <div class="page-header page-header-small">
    <div class="page-header-image" data-parallax="true" style="background-image: url('<?php echo e(asset('/img/bg6.jpg')); ?>');">
    </div>
      <div class="content-center">
        <div class="container">
          <h1 class="title">Vista de Niveles</h1>
        <div class="text-center">
      </div>
      </div>
    </div>
  </div>
  <div class="section section-about-us">
    <div class="container">
      <div class="row">
        <div class="col-md-8 ml-auto mr-auto text-center">
          <h2 class="title">Registro de Niveles</h2>
           <form method="post" action<?php echo e(url('/Usuario/Nivel/'.$actlevel->id.'/edicion')); ?>>
            <?php echo csrf_field(); ?>
            <div class="card card-nav-tabs card-plain">
              <div class="card-header card-header-danger">
                <div class="text-right">
                <a href="<?php echo e(url('/Usuario/Nivel/')); ?>" type="button" class="btn btn-primary now-ui-icons arrows-1_minimal-left">&nbsp;Regresar</a>
                </div>
                <div class="nav-tabs-navigation">
                  <div class="nav-tabs-wrapper">
                    <ul class="nav nav-tabs" data-tabs="tabs">
                        <li class="nav-item">
                            <a class="nav-link active" href="#datos_g" data-toggle="tab">Datos Generales</a>
                        </li>
                    </ul>
                  </div>
                </div>
              </div>
              <?php
                $grades=App\grade::all();
                $groups=App\group::all();
                $levels=App\level::all();
                $Turns=App\Turn::all();
                ?>
              <div class="card-body ">
                <div class="tab-content text-center">
                  <div class="form-group">
                    <label for="exampleFormControlSelect1">Nivel escolar</label>
                    <select class="form-control" name="level_id" id="exampleFormControlSelect1" value="<?php echo e($actlevel->level->nivel_educativo); ?>">
                    <?php $__currentLoopData = $levels; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $level): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($level->id); ?>"><?php echo e($level->nivel_educativo); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                  </div>
                <div class="form-group">
                  <label for="exampleFormControlSelect1">Turno</label>
                  <select class="form-control"  name="turno_id" id="exampleFormControlSelect1" value="<?php echo e($actlevel->Turn->Turno); ?>">
                  <?php $__currentLoopData = $Turns; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $Turn): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($Turn->id); ?>"><?php echo e($Turn->Turno); ?></option>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                  </select>
                </div>
                <div class="form-group">
                <label for="exampleFormControlSelect1">Grado</label>
                  <select class="form-control" name="grado_id" id="exampleFormControlSelect1" value="<?php echo e($actlevel->grade->grado); ?>">
                    <?php $__currentLoopData = $grades; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $grade): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($grade->id); ?>"><?php echo e($grade->grado); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                  </select>
                </div>
                
              <div class="form-group">
                <label for="exampleFormControlSelect1">Grupo</label>
                  <select class="form-control" name="grupo_id" id="exampleFormControlSelect1" value="<?php echo e($actlevel->group->grupo); ?>">
                    <?php $__currentLoopData = $groups; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $group): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($group->id); ?>"><?php echo e($group->grupo); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                  </select>
              </div>
                  <button type="submit" class="btn btn-primary">Registrar</button>
                </div>
              </div>
            </div>
      </form>
        </div>
      </div>
    </div>
  </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>