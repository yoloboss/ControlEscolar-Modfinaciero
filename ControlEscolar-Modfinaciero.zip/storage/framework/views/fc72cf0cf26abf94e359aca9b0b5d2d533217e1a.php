<?php $__env->startSection('body-class','landing-page sidebar-collapse'); ?>

<?php $__env->startSection('content'); ?>
<div class="wrapper">
  <div class="page-header page-header-small">
    <div class="page-header-image" data-parallax="true" style="background-image: url('<?php echo e(asset('/img/bg6.jpg')); ?>');">
    </div>
      <div class="content-center">
        <div class="container">
          <h1 class="title">Vista de conceptos de pago</h1>
        <div class="text-center">
      </div>
      </div>
    </div>
  </div>
  <div class="section section-about-us">
    <div class="container">
      <div class="row">
        <div class="col-md-8 ml-auto mr-auto text-center">
          <h2 class="title">Registro de nueovs coneptos de pago</h2>
           <form method="post" action="<?php echo e(url('/Usuario/concepto_pago/'.$concept->id.'/edicion')); ?>">
            <?php echo csrf_field(); ?>
            <div class="form-group">
              <label for="exampleFormControlInput1">Nombre del concepto</label>
              <input type="text" class="form-control" id="exampleFormControlInput1" placeholder="Nombre del cncepto..." name="nombre" value="<?php echo e($concept->nombre); ?>">
            </div>
            <div class="form-group">
              <label for="exampleFormControlTextarea1">concepto</label>
              <textarea class="form-control" name="concepto" id="exampleFormControlTextarea1" rows="3">   <?php echo e($concept->concepto); ?></textarea>
            </div>
            <div class="form-group">
              <label for="exampleFormControlInput1">Precio</label>
              <input type="text" class="form-control" id="exampleFormControlInput1" placeholder="descricion del concepto..." name="precio"  value="<?php echo e($concept->precio); ?>">
            </div>
            <div class="form-group">
              <label for="exampleFormControlSelect1">Estatus del ciclo</label>
              <select class="form-control" id="exampleFormControlSelect1" name="status" value="<?php echo e($concept->status); ?>">
                <option>Activo</option>
                <option>Inactivo</option>
              </select>
            </div>
            <button type="submit" class="btn btn-primary">Registrar</button>
          </form>
        </div>
      </div>
    </div>
  </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>