<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class payment_concept extends Model
{
    //
}
