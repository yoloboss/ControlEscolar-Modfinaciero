<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\level;

class levelcontroller extends Controller
{
    
}
